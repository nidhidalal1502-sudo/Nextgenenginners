import pytest
from src.storage.local_store import LocalStore, ObjectNotFoundError, CorruptionError


@pytest.fixture
def store(tmp_path):
    return LocalStore(base_dir=str(tmp_path))


def test_put_and_get(store):
    data = b"hello duniya"
    object_id = store.put(data)
    retrieved = store.get(object_id)
    assert retrieved == data


def test_get_nonexistent_object(store):
    with pytest.raises(ObjectNotFoundError):
        store.get("fake_id_123")


def test_delete_object(store):
    object_id = store.put(b"delete mujhe")
    store.delete(object_id)
    assert not store.exists(object_id)


def test_corruption_detected(store):
    object_id = store.put(b"important data")
    # jaan-boojh kar file ko corrupt karo
    obj_path = store._object_path(object_id)
    with open(obj_path, "wb") as f:
        f.write(b"tampered data")

    with pytest.raises(CorruptionError):
        store.get(object_id)
