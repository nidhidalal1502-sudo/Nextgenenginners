import hashlib
import json
import os


class CorruptionError(Exception):
    """Jab stored object ka checksum match nahi karta"""
    pass


class ObjectNotFoundError(Exception):
    pass


class LocalStore:
    def __init__(self, base_dir="data"):
        self.base_dir = base_dir
        os.makedirs(self.base_dir, exist_ok=True)

    def _compute_hash(self, data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()

    def _object_path(self, object_id: str) -> str:
        return os.path.join(self.base_dir, object_id + ".obj")

    def _meta_path(self, object_id: str) -> str:
        return os.path.join(self.base_dir, object_id + ".meta.json")

    def put(self, data: bytes) -> str:
        """Object save karo, object_id (hash) return karo"""
        object_id = self._compute_hash(data)

        with open(self._object_path(object_id), "wb") as f:
            f.write(data)

        meta = {"object_id": object_id, "size": len(data), "checksum": object_id}
        with open(self._meta_path(object_id), "w") as f:
            json.dump(meta, f)

        return object_id

    def get(self, object_id: str) -> bytes:
        """Object padho, checksum verify karo, corrupt hua to error do"""
        path = self._object_path(object_id)
        if not os.path.exists(path):
            raise ObjectNotFoundError(f"Object {object_id} nahi mila")

        with open(path, "rb") as f:
            data = f.read()

        actual_hash = self._compute_hash(data)
        if actual_hash != object_id:
            raise CorruptionError(
                f"Object {object_id} corrupt hai! Expected {object_id}, mila {actual_hash}"
            )

        return data

    def delete(self, object_id: str) -> None:
        obj_path = self._object_path(object_id)
        meta_path = self._meta_path(object_id)

        if not os.path.exists(obj_path):
            raise ObjectNotFoundError(f"Object {object_id} nahi mila")

        os.remove(obj_path)
        if os.path.exists(meta_path):
            os.remove(meta_path)

    def exists(self, object_id: str) -> bool:
        return os.path.exists(self._object_path(object_id))
